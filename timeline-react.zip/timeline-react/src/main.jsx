import React from "react";
import ReactDOM from "react-dom";
import Main from "./App";
import './index.css'


const x = ReactDOM.createRoot(document.getElementById('root'))
x.render(
<Main />
)