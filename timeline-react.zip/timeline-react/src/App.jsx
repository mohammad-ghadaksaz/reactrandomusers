import Header from './components/Header'
import Article from './components/article'


export default function Main(){
return(
  <>
  <Header />
  <Article />
  </>
)


}